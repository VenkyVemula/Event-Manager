### Few instructions to start application
## To run as docker containter
- docker build -t nextjs-graphql-app .
- docker run -p 3000:3000 nextjs-graphql-app
## To run on local setup
- npm install
- rmp run build
- rpn run dev
## user name and password
- user :admin
- password: password123
