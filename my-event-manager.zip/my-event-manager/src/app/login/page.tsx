/* "use client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { gql, useMutation } from "@apollo/client";
import { useRouter } from "next/navigation";
import { useAuth } from "../../lib/auth";

//const LOGIN = gql`mutation Login($u:String!,$p:String!){login(username:$u,password:$p)}`;
const LOGIN = gql`
  mutation Login($username: String!, $password: String!) {
    login(username: $username, password: $password)
  }
`;

export default function LoginPage() {
  const router = useRouter();
  const { setToken } = useAuth();
  const [login] = useMutation(LOGIN);

  return (
    <div className="max-w-md mx-auto mt-20 p-6 border">
      <Formik
        initialValues={{ username: "", password: "" }}
        validationSchema={Yup.object({
          username: Yup.string().required(),
          password: Yup.string().required(),
        })}
        onSubmit={async (v) => {
          //const { data } = await login({ variables: { u: v.username, p: v.password } });
          const { data } = await login({
            variables: { username: v.username, password: v.password },
          });
          setToken(data.login);
          router.push("/events");
        }}
      >
        {({ errors, touched }) => (
          <Form className="flex flex-col space-y-4">
            <Field
              name="username"
              placeholder="Username"
              className="border p-2"
            />
            {errors.username && touched.username && (
              <div>{errors.username}</div>
            )}
            <Field
              type="password"
              name="password"
              placeholder="Password"
              className="border p-2"
            />
            {errors.password && touched.password && (
              <div>{errors.password}</div>
            )}
            <button type="submit" className="bg-blue-500 text-white p-2">
              Login
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}
 */

"use client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { gql, useMutation } from "@apollo/client";
import { useRouter } from "next/navigation";
import { useAuth } from "../../lib/auth";

const LOGIN = gql`
  mutation Login($username: String!, $password: String!) {
    login(username: $username, password: $password)
  }
`;

export default function LoginPage() {
  const router = useRouter();
  const { setToken } = useAuth();
  const [login] = useMutation(LOGIN);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
      {/* Header */}
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-blue-700">Event Managemer</h1>
      </header>

      {/* Login Form */}
      <div className="w-full max-w-md bg-white p-6 rounded shadow-md">
        <Formik
          initialValues={{ username: "", password: "" }}
          validationSchema={Yup.object({
            username: Yup.string().required("Username is required"),
            password: Yup.string().required("Password is required"),
          })}
          onSubmit={async (values, { setSubmitting, setErrors }) => {
            try {
              const { data } = await login({
                variables: {
                  username: values.username,
                  password: values.password,
                },
              });
              setToken(data.login);
              router.push("/events");
            } catch (error) {
              console.debug(error);
              setErrors({ password: "Invalid username or password" });
            } finally {
              setSubmitting(false);
            }
          }}
        >
          {({ errors, touched }) => (
            <Form className="flex flex-col space-y-4">
              <div>
                <Field
                  name="username"
                  placeholder="Username"
                  className="w-full border p-2 rounded"
                />
                {errors.username && touched.username && (
                  <div className="text-red-500 text-sm mt-1">
                    {errors.username}
                  </div>
                )}
              </div>

              <div>
                <Field
                  type="password"
                  name="password"
                  placeholder="Password"
                  className="w-full border p-2 rounded"
                />
                {errors.password && touched.password && (
                  <div className="text-red-500 text-sm mt-1">
                    {errors.password}
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 rounded"
              >
                Login
              </button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}
