"use client";

import { gql, useQuery, useMutation } from "@apollo/client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { Event } from "@/types/event";

import EventHeader from "@/components/events/EventHeader";
import Sidebar from "@/components/events/Sidebar";
import NewEventForm from "@/components/events/NewEventForm";
import EventList from "@/components/events/EventList";

const GET_EVENTS = gql`
  query {
    events {
      id
      title
      date
      attendees {
        id
      }
    }
  }
`;

const CREATE_EVENT = gql`
  mutation CreateEvent($title: String!, $date: String!) {
    createEvent(title: $title, date: $date) {
      id
      title
      date
      attendees {
        id
      }
    }
  }
`;

export default function EventsPage() {
  const { token, setToken, initializeToken } = useAuth();
  const router = useRouter();
  const { data, loading, refetch } = useQuery<{ events: Event[] }>(GET_EVENTS);
  const [createEvent] = useMutation(CREATE_EVENT);

  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    initializeToken();
  }, []);

  useEffect(() => {
    if (!token) router.push("/login");
  }, [token, router]);

  if (!token) return null;
  if (loading) return <div>Loading...</div>;

  const handleCreate = async (title: string, date: string) => {
    try {
      await createEvent({ variables: { title, date } });
      setShowForm(false);
      refetch();
    } catch (err) {
      alert("Failed to create event"+err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <EventHeader setToken={setToken} />
      <div className="flex flex-1">
        <Sidebar onNewEvent={() => setShowForm(true)} />
        <main className="flex-1 p-6">
          <h2 className="text-xl mb-4">Your Events</h2>
          {showForm && (
            <NewEventForm onCreate={handleCreate} onCancel={() => setShowForm(false)} />
          )}
          <EventList events={data?.events || []} />
        </main>
      </div>
    </div>
  );
}
