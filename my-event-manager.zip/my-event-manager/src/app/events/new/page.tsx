"use client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { gql, useMutation } from "@apollo/client";
import { useRouter } from "next/navigation";

const CREATE = gql`
  mutation ($t: String!, $d: String!) {
    createEvent(title: $t, date: $d) {
      id
    }
  }
`;

export default function NewEvent() {
  const router = useRouter();
  const [createEvent] = useMutation(CREATE);

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-xl mb-4">Create Event</h1>
      <Formik
        initialValues={{ title: "", date: "" }}
        validationSchema={Yup.object({
          title: Yup.string().required(),
          date: Yup.date().required(),
        })}
        onSubmit={async (v) => {
          await createEvent({ variables: { t: v.title, d: v.date } });
          router.push("/events");
        }}
      >
        {({ errors, touched }) => (
          <Form className="flex flex-col space-y-4">
            <Field name="title" placeholder="Title" className="border p-2" />
            {errors.title && touched.title && <div>{errors.title}</div>}
            <Field name="date" type="date" className="border p-2" />
            {errors.date && touched.date && <div>{errors.date}</div>}
            <button type="submit" className="bg-blue-500 text-white p-2">
              Create
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}
