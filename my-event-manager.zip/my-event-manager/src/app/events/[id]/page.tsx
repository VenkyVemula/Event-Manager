import EventDetails from "@/components/events/EventDetails";
type PageProps = {
  params: Promise<{ id: string }>;
};
export default async function EventPage({ params }: PageProps) {
  const resolvedParams = await params;
  return <EventDetails eventId={resolvedParams.id} />;
}
