import { ApolloServer } from "apollo-server-micro";
import { eventTypeDefs as typeDefs } from "@/graphql/events/eventSchema";
import { eventResolvers as resolvers } from "@/graphql/events/eventResolvers";
//import { typeDefs } from '../../graphql/events/eventSchema';
//import { resolvers } from '@/graphql/resolvers';
import { NextApiRequest, NextApiResponse } from "next";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();
const SECRET = process.env.JWT_SECRET || "default_secret";

const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: ({ req }) => {
    const token = req.headers.authorization?.split(" ")[1];

    if (token) {
      try {
        const user = jwt.verify(token, SECRET);
        return { user };
      } catch (err) {
        console.error(err);
      }
    }
    return {};
  },
});

const startServer = server.start();

export const config = { api: { bodyParser: false } };

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  await startServer;
  return server.createHandler({ path: "/api/graphql" })(req, res);
}
