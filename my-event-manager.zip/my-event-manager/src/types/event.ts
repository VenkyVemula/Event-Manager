export interface User {
  id: string;
  name: string;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  attendees: Attendee[];
}

export interface Attendee {
  id: string;
  name: string;
  email?: string | null;
}

export interface Context {
  user?: User | null;
}

export interface EventIdArgs {
  id: string;
}

export interface CreateEventArgs {
  title: string;
  date: string;
}

export interface AddAttendeeArgs {
  eventId: string;
  name: string;
  email?: string | null;
}

export interface RemoveAttendeeArgs {
  eventId: string;
  attendeeId: string;
}
