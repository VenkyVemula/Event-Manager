export const eventTypeDefs = `
  type Query {
    _empty: String
  }
  
  type Mutation {
    _empty: String
  }

  type Attendee {
    id: ID!
    name: String!
    email: String
  }

  type Event {
    id: ID!
    title: String!
    date: String!
    attendees: [Attendee!]!
  }

  extend type Query {
    events: [Event!]!
    event(id: ID!): Event
  }

  extend type Mutation {
    createEvent(title: String!, date: String!): Event
    addAttendee(eventId: ID!, name: String!, email: String): Attendee
    removeAttendee(eventId: ID!, attendeeId: ID!): Boolean
    login(username: String!, password: String!): String
  }
`;
