/* import jwt from "jsonwebtoken";

const SECRET = process.env.JWT_SECRET || "default_secret";
import { dataStore } from "./eventData";
import {
  Context,
  EventIdArgs,
  CreateEventArgs,
  AddAttendeeArgs,
  RemoveAttendeeArgs,
  Event,
  Attendee,
} from "../../types/event";

const { events } = dataStore;
let { eventCounter, attCounter } = dataStore;

export const eventResolvers = {
  Query: {
    events: (_parent: unknown, _args: unknown, context: Context): Event[] =>
      context.user ? events : [],

    event: (_parent: unknown, args: EventIdArgs): Event | undefined => {
      console.log(events.length + "<------------------->" + args.id);
      return events.find((e) => e.id === args.id);
    },
  },

  Mutation: {
    createEvent: (
      _parent: unknown,
      args: CreateEventArgs,
      context: Context
    ): Event => {
      if (!context.user) throw new Error("Unauthorized");
      const event: Event = {
        id: `${eventCounter++}`,
        title: args.title,
        date: args.date,
        attendees: [],
      };
      console.log("event==create=======>" + event);
      events.push(event);
      console.log("event==create after===size====>" + events.length);
      return event;
    },

    addAttendee: (
      _parent: unknown,
      args: AddAttendeeArgs,
      context: Context
    ): Attendee => {
      if (!context.user) throw new Error("Unauthorized");
      const event = events.find((e) => e.id === args.eventId);
      if (!event) throw new Error("Event not found");
      const attendee: Attendee = {
        id: `${attCounter++}`,
        name: args.name,
        email: args.email ?? null,
      };
      event.attendees.push(attendee);
      return attendee;
    },

    removeAttendee: (
      _parent: unknown,
      args: RemoveAttendeeArgs,
      context: Context
    ): boolean => {
      if (!context.user) throw new Error("Unauthorized");
      const event = events.find((e) => e.id === args.eventId);
      if (!event) throw new Error("Event not found");
      event.attendees = event.attendees.filter((a) => a.id !== args.attendeeId);
      return true;
    },
    login: async (
      _parent: unknown,
      { username, password }: { username: string; password: string }
    ) => {
      if (username === "admin" && password === "password123") {
        // For example, return a dummy JWT token or a string:
        // return "dummy.jwt.token";
        const token = jwt.sign({ username }, SECRET, { expiresIn: "1h" }); // payload, secret, options
        return token;
      }
      throw new Error("Invalid credentials");
    },
  },
};
 */

import jwt from "jsonwebtoken";
import { dataStore } from "./eventData";
import {
  Context,
  EventIdArgs,
  CreateEventArgs,
  AddAttendeeArgs,
  RemoveAttendeeArgs,
  Event,
  Attendee,
} from "../../types/event";

const SECRET = process.env.JWT_SECRET || "default_secret";

const { events } = dataStore;
let { eventCounter, attCounter } = dataStore;

// In-memory user store
const users = [
  { username: "admin", password: "password123" },
  { username: "john", password: "johnpass" },
];

export const eventResolvers = {
  Query: {
    events: (_parent: unknown, _args: unknown, context: Context): Event[] =>
      context.user ? events : [],

    event: (_parent: unknown, args: EventIdArgs): Event | undefined => {
      console.log(events.length + "<------------------->" + args.id);
      return events.find((e) => e.id === args.id);
    },
  },

  Mutation: {
    createEvent: (
      _parent: unknown,
      args: CreateEventArgs,
      context: Context
    ): Event => {
      if (!context.user) throw new Error("Unauthorized");

      const event: Event = {
        id: `${eventCounter++}`,
        title: args.title,
        date: args.date,
        attendees: [],
      };

      console.log("event==create=======>" + event);
      events.push(event);
      console.log("event==create after===size====>" + events.length);

      return event;
    },

    addAttendee: (
      _parent: unknown,
      args: AddAttendeeArgs,
      context: Context
    ): Attendee => {
      if (!context.user) throw new Error("Unauthorized");

      const event = events.find((e) => e.id === args.eventId);
      if (!event) throw new Error("Event not found");

      const attendee: Attendee = {
        id: `${attCounter++}`,
        name: args.name,
        email: args.email ?? null,
      };

      event.attendees.push(attendee);
      return attendee;
    },

    removeAttendee: (
      _parent: unknown,
      args: RemoveAttendeeArgs,
      context: Context
    ): boolean => {
      if (!context.user) throw new Error("Unauthorized");

      const event = events.find((e) => e.id === args.eventId);
      if (!event) throw new Error("Event not found");

      event.attendees = event.attendees.filter((a) => a.id !== args.attendeeId);
      return true;
    },

    login: async (
      _parent: unknown,
      { username, password }: { username: string; password: string }
    ): Promise<string> => {
      const user = users.find(
        (u) => u.username === username && u.password === password
      );

      if (!user) throw new Error("Invalid credentials");

      const token = jwt.sign({ username: user.username }, SECRET, {
        expiresIn: "1h",
      });

      return token;
    },
  },
};
