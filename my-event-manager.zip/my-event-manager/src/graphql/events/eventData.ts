import { Event } from "@/types/event";

export const dataStore = {
  events: [] as Event[],
  eventCounter: 1,
  attCounter: 1,
};
