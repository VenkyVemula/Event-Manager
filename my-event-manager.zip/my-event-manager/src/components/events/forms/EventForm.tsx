"use client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { gql, useMutation } from "@apollo/client";
import { useRouter } from "next/navigation";

const CREATE_EVENT = gql`
  mutation ($title: String!, $date: String!) {
    createEvent(title: $title, date: $date) {
      id
    }
  }
`;

export default function EventForm() {
  const router = useRouter();
  const [createEvent] = useMutation(CREATE_EVENT);

  return (
    <Formik
      initialValues={{ title: "", date: "" }}
      validationSchema={Yup.object({
        title: Yup.string().required(),
        date: Yup.string().required(),
      })}
      onSubmit={async (values) => {
        await createEvent({ variables: values });
        router.push("/events");
      }}
    >
      {() => (
        <Form className="space-y-4">
          <Field
            name="title"
            className="w-full p-2 border"
            placeholder="Event Title"
          />
          <Field name="date" type="date" className="w-full p-2 border" />
          <button type="submit" className="bg-blue-600 text-white px-4 py-2">
            Create
          </button>
        </Form>
      )}
    </Formik>
  );
}
