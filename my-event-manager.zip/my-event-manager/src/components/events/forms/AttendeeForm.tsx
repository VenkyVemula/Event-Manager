"use client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { gql, useMutation } from "@apollo/client";

const ADD_ATTENDEE = gql`
  mutation ($eventId: ID!, $name: String!, $email: String) {
    addAttendee(eventId: $eventId, name: $name, email: $email) {
      id
    }
  }
`;

export default function AttendeeForm({
  eventId,
  onAdd,
}: {
  eventId: string;
  onAdd: () => void;
}) {
  const [addAttendee] = useMutation(ADD_ATTENDEE);

  return (
    <div className="mt-4">
      <h4 className="font-semibold mb-2">Add Attendee</h4>
      <Formik
        initialValues={{ name: "", email: "" }}
        validationSchema={Yup.object({
          name: Yup.string().required(),
          email: Yup.string().email().notRequired(),
        })}
        onSubmit={async (values, { resetForm }) => {
          await addAttendee({ variables: { eventId, ...values } });
          resetForm();
          onAdd();
        }}
      >
        {() => (
          <Form className="space-y-2">
            <Field
              name="name"
              placeholder="Name"
              className="w-full border p-2"
            />
            <Field
              name="email"
              placeholder="Email (optional)"
              className="w-full border p-2"
            />
            <button type="submit" className="bg-green-600 text-white px-3 py-1">
              Add
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}
