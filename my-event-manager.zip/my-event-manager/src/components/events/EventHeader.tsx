//NEW
"use client";
import { useRouter } from "next/navigation";

export default function EventHeader({ setToken }: { setToken: (t: string | null) => void }) {
  const router = useRouter();

  return (
    <header className="flex justify-between items-center bg-blue-600 text-white p-4">
      <h1 className="text-2xl font-bold">Event Manager</h1>
      <div className="flex items-center space-x-4">
        <span>Welcome, User!</span>
        <button
          onClick={() => {
            setToken(null);
            router.push("/login");
          }}
          className="bg-red-500 hover:bg-red-600 px-3 py-1 rounded"
        >
          Logout
        </button>
      </div>
    </header>
  );
}
