//New
"use client";
import Link from "next/link";

export default function Sidebar({ onNewEvent }: { onNewEvent: () => void }) {
  return (
    <nav className="w-48 bg-gray-100 p-4 border-r">
      <button
        onClick={onNewEvent}
        className="w-full mb-4 bg-green-500 text-white p-2 rounded hover:bg-green-600"
      >
        + New Event
      </button>
      <ul>
        <li className="mb-2">
          <Link href="/events" className="block p-2 rounded hover:bg-gray-200">
            Events
          </Link>
        </li>
      </ul>
    </nav>
  );
}
