"use client";
import { gql, useQuery, useMutation } from "@apollo/client";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import Link from "next/link";
import { Attendee } from "@/types/event";

const GET_EVENT = gql`
  query ($id: ID!) {
    event(id: $id) {
      id
      title
      date
      attendees {
        id
        name
        email
      }
    }
  }
`;

const ADD = gql`
  mutation ($e: ID!, $n: String!, $em: String) {
    addAttendee(eventId: $e, name: $n, email: $em) {
      id
    }
  }
`;

const REMOVE = gql`
  mutation ($e: ID!, $a: ID!) {
    removeAttendee(eventId: $e, attendeeId: $a)
  }
`;

interface Props {
  eventId: string;
}

export default function EventDetails({ eventId }: Props) {
  const { data, loading, refetch } = useQuery(GET_EVENT, {
    variables: { id: eventId },
  });
  const [add] = useMutation(ADD);
  const [remove] = useMutation(REMOVE);

  if (loading) return <div>Loading...</div>;

  //const e = data.event;
const e = data?.event;

if (!e) {
  return (
    <div className="p-6 max-w-2xl mx-auto text-center text-red-500">
      Event not found.
    </div>
  );
}
  return (
    <div className="p-6 max-w-2xl mx-auto">
      {/* 🔙 Back Link */}
      <Link href="/events" className="text-blue-500 underline mb-4 block">
        ← Back to Events
      </Link>

      <h1 className="text-2xl text-red-600 mb-2">{e.title}</h1>
      <div className="mb-4 text-gray-600">
        {new Date(e.date).toLocaleDateString()}
      </div>

      <h2 className="text-xl mb-2">Attendees</h2>
      <ul>
        {e.attendees.map((a: Attendee) => (
          <li
            key={a.id}
            className="flex justify-between border p-2 my-1 bg-green-100 rounded"
          >
            <div>
              {a.name} {a.email && `(${a.email})`}
            </div>
            <button
              className="text-red-500"
              onClick={async () => {
                await remove({ variables: { e: e.id, a: a.id } });
                refetch();
              }}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        <h3 className="text-lg mb-2">Add Attendee</h3>
        <Formik
          initialValues={{ name: "", email: "" }}
          validationSchema={Yup.object({
            name: Yup.string().required("Name is required"),
            email: Yup.string().email("Invalid email"),
          })}
          onSubmit={async (v, { resetForm }) => {
            await add({
              variables: { e: e.id, n: v.name, em: v.email || null },
            });
            resetForm();
            refetch();
          }}
        >
          {({ errors, touched }) => (
            <Form className="flex flex-col space-y-2">
              <Field
                name="name"
                placeholder="Name"
                className="border p-2 rounded"
              />
              {touched.name && errors.name && (
                <div className="text-red-500">{errors.name}</div>
              )}
              <Field
                name="email"
                placeholder="Email (optional)"
                className="border p-2 rounded"
              />
              <button
                type="submit"
                className="bg-green-500 text-white px-4 py-2 rounded w-fit"
              >
                Add
              </button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}
