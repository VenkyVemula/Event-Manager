import Link from "next/link";
import { Event } from "@/types/event";

export default function EventCard({ event }: { event: Event }) {
  return (
    <div className="border p-4 mb-2">
      <Link href={`/events/${event.id}`}>
        <h2 className="text-xl font-semibold">{event.title}</h2>
        <p>Date: {new Date(event.date).toLocaleDateString()}</p>
        <p>Attendees: {event.attendees.length}</p>
      </Link>
    </div>
  );
}
