/* "use client";
import { gql, useQuery } from "@apollo/client";
import EventCard from "./EventCard";
import { Event } from "@/types/event";

interface EventsQueryData {
  events: Event[];
}

const EVENTS_QUERY = gql`
  query {
    events {
      id
      title
      date
      attendees {
        id
      }
    }
  }
`;

export default function EventList() {
  const { data, loading, error } = useQuery<EventsQueryData>(EVENTS_QUERY);

  if (loading) return <p>Loading events...</p>;
  if (error) return <p>Error loading events.</p>;

  return (
    <div className="space-y-4">
      {data?.events.map((event) => (
        <EventCard key={event.id} event={event} />
      ))}
    </div>
  );
}
 */

"use client";
import Link from "next/link";
import { Event } from "@/types/event";

export default function EventList({ events }: { events: Event[] }) {
  if (events.length === 0) return <p>No events found.</p>;

  return (
    <ul>
      {events.map((e) => (
        <li
          key={e.id}
          className="border p-4 mb-3 rounded bg-green-50 hover:bg-green-100 cursor-pointer"
        >
          <Link href={`/events/${e.id}`}>
            <div className="font-semibold">{e.title}</div>
            <div className="text-sm text-gray-600">
              {new Date(e.date).toLocaleDateString()}
            </div>
            <div className="text-sm text-gray-700">
              <b>{e.attendees.length}</b> attendees
            </div>
          </Link>
        </li>
      ))}
    </ul>
  );
}

