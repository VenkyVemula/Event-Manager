//new
"use client";
import { useState } from "react";

export default function NewEventForm({
  onCreate,
  onCancel,
}: {
  onCreate: (title: string, date: string) => void;
  onCancel: () => void;
}) {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date) return;
    onCreate(title, date);
    setTitle("");
    setDate("");
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white border rounded p-4 mb-6 shadow-md max-w-md"
    >
      <h3 className="text-lg font-bold mb-2">Create New Event</h3>
      <input
        type="text"
        placeholder="Event Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <div className="flex space-x-2">
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
          Create
        </button>
        <button type="button" onClick={onCancel} className="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">
          Cancel
        </button>
      </div>
    </form>
  );
}
