 "use client";

import { create } from "zustand";

interface AuthState {
  token: string | null;
  setToken: (t: string | null) => void;
  initializeToken: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  token: null,
  setToken: (t) => {
    if (typeof window !== "undefined") {
      if (t) {
        localStorage.setItem("token", t);
      } else {
        localStorage.removeItem("token");
      }
    }
    set({ token: t });
  },
  initializeToken: () => {
    if (typeof window !== "undefined") {
      const storedToken = localStorage.getItem("token");
      set({ token: storedToken });
    }
  },
}));
 
