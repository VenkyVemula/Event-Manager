### Entity Relationship Design
## User(Represents authenticated users who create/manage events)

- Attribute	Type	    Description
- id	        UUID	    Primary key
- name	    String	    Full name
- email	    String	    Unique email(index)
- created_at	DateTime	Timestamp

## Event(Represents a scheduled event)

- Attribute	Type	Description
- id	        UUID	Primary key
- title	    String	Title of the event
- created_by	UUID	Foreign key to User.id - and required(index)
- created_at	DateTime	Timestamp


## Attendee(Represents a person who an event.)

- Attribute	Type	Description
- id	        UUID	Primary key
- name	    String	Full name
- email	    String	email (optional)
- created_at	DateTime	Timestamp

## Attendance (Join Table that Tracks the relationship between Attendee and Event)

- Attribute	Type	Description
- event_id	UUID	Foreign key to Event.id
- attendee_id	UUID	Foreign key to Attendee.id
- rsvp_status	Enum	RSVP status: Going(Default), Not Going, Maybe, Pending

Constraints:
- Composite Index and Primary Key: (event_id, attendee_id)

## Tag(Represents a reusable label or category for events)

- Attribute	Type	Description
- id	        UUID	Primary key
- name	    String	Tag name(case-insensitive - unique index)

## EventTag (Join Table for Event–Tag many-to-many)

- Attribute	Type	Description
- event_id	UUID	Foreign key (Event.id)
- tag_id	    UUID	Foreign key (Tag.id)

- Composite Primary Key: (event_id, tag_id)
- Index on event_id, tag_id
