Assuming this is small/medium size app based on team size/deployment strategy followed below style
I choose monorepo style code structure
Not covered unit/integraton test cases
Cant spend much time on CSS styling, even I am not expert in writing CSS
Refactor:Types declaration need to move into single location